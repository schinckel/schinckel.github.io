//
//  LocationDayController.h
//  Simple Roster
//
//  Created by Matthew Schinckel on 9/07/08.
//  Copyright 2008 Special Sauce Software. All rights reserved.
//

// This is a controller for interfacing an NSSegmentedControl with an NSArrayController,
// where the first item is Select/Deselect All.

#import <Cocoa/Cocoa.h>


@interface SegmentController : NSObject {
    IBOutlet NSSegmentedControl *control;
    IBOutlet NSArrayController *arrayController;
    NSArray *sortDescriptors;
    NSMutableIndexSet *selectionIndexes;
}

- (IBAction)selectSegment:(id)sender;
- (void)updateControl;

@property (retain) NSMutableIndexSet *selectionIndexes;

@end
