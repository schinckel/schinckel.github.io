//
//  SegmentController.m
//  Simple Roster
//
//  Created by Matthew Schinckel on 9/07/08.
//  Copyright 2008 Special Sauce Software. All rights reserved.
//

#import "SegmentController.h"


@implementation SegmentController

- (void) awakeFromNib {
    //NSLog([arrayController description]);
    sortDescriptors = [NSArray arrayWithObject:[[NSSortDescriptor new] initWithKey:@"index"
                                                                   ascending:YES]];
    [sortDescriptors retain];
    
    // Without this next line (ie, with just an IB hookup the sort doesn't work.
    [arrayController setSortDescriptors:sortDescriptors];
    
    // initialise the storage for the selection indexes.
    // Don't need an explicit retain here as it's a property (retain).
    selectionIndexes = [[NSMutableIndexSet alloc] init];
    
    // Set up the control.
    // Can't figure out how to force the fetch of everything, and
    // at this stage the array is empty.
    //[arrayController setFilterPredicate:nil];
    //NSLog(@"%i", [[arrayController arrangedObjects] count]);
    
}
- (IBAction)selectSegment:(id)sender {
    
    // If the first item is now selected, then select all of the other items, 
    // and make all of the other segments selected too.
    int selected = [control selectedSegment];
    
    if (selected == 0) {
        BOOL sel = [control isSelectedForSegment:0];
        int i;
        int count = [control segmentCount];
        for (i=1 ; i < count ; i++ ) {
            [control setSelected:sel forSegment:i];
        }
    } else {
        [self updateControl];
    }
    
    // Okay, now we need to see which items are selected, and
    // select the same objects in the sorted arrayController.
    
    int i;
    [selectionIndexes removeAllIndexes];
    int count = [control segmentCount];
    for (i=1 ; i < count ; i++) {
        if ([control isSelectedForSegment:i]) {
            [selectionIndexes addIndex:(i-1)];
        }
    }
    
    // We shouldn't need to do this, since it is connected using a Binding, but
    // it doesn't update properly otherwise.
    [arrayController setSelectionIndexes:selectionIndexes];
}

- (void) updateControl {
    // If all of the other controls are selected, then select the first one, else
    // deselect it.
    int i=1;
    int count = [control segmentCount];
    BOOL sel = YES;
    while (sel && i < count) {
        sel = [control isSelectedForSegment:i];
        i++;
    }
    [control setSelected:sel forSegment:0];
}

- (NSMutableIndexSet *)selectionIndexes {
    return selectionIndexes;
}

- (void) setSelectionIndexes:(NSMutableIndexSet *)indexes {
    // Grab the data from the incoming message and set all of our
    // segments accordingly.
    [selectionIndexes removeAllIndexes];
    [selectionIndexes addIndexes:indexes];
    int i;
    int count = [control segmentCount];
    for (i=0; i < count-1 ; i++) {
        [control setSelected:[selectionIndexes containsIndex:i] forSegment:i+1]; 
    }
    // Now set the first one, depending upon the values of the others.
    [self updateControl];
}

@end
